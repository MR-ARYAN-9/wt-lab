<?php
// includes/footer.php - site footer
?>
</main>
<footer class="site-footer">
  <div class="container">
    <p>&copy; <?php echo date('Y'); ?> Student Project Management System</p>
  </div>
</footer>
</body>
</html>
