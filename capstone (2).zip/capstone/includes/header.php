<?php
// includes/header.php - site header and navigation
// Assumes config.php is already required in the including file
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Student Project Management System</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/main.js" defer></script>
</head>
<body>
<header class="site-header">
  <div class="container nav-container">
    <div class="brand"><a href="index.php">SPMS</a></div>
    <nav class="main-nav">
      <a href="index.php">Home</a>
      <a href="about.php">About</a>
      <a href="projects.php">Projects</a>
      <a href="contact.php">Contact</a>
      <?php if (is_logged_in()): ?>
        <a href="dashboard.php">Dashboard</a>
        <a href="upload.php">Upload</a>
        <a href="logout.php" class="btn-logout">Logout</a>
      <?php else: ?>
        <a href="register.php">Register</a>
        <a href="login.php">Login</a>
      <?php endif; ?>
    </nav>
    <button class="nav-toggle" aria-label="Toggle navigation">☰</button>
  </div>
</header>
<main class="container">
