<?php
// config.php - database connection and common helpers
session_start();

// === Database credentials ===
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // adjust if you have a password
define('DB_NAME', 'student_projects');

// Upload directory
define('UPLOAD_DIR', __DIR__ . '/uploads/');

// Create mysqli connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die('Database connection failed: ' . $conn->connect_error);
}

// Basic escaping helper
function esc($str)
{
    global $conn;
    return htmlspecialchars($conn->real_escape_string(trim($str)));
}

// Simple auth helper
function is_logged_in()
{
    return isset($_SESSION['user_id']);
}

function require_login()
{
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

?>
